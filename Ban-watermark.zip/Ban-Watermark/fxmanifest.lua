fx_version 'cerulean'
game 'gta5'
author 'Ban'


ui_page 'web/index.html'
files{
    'web/index.html',
    'web/css/*.css',
    'web/assets/logo.png'
}

escrow_ignore {
    'css/logo.css',
    'css/styles.css'
}